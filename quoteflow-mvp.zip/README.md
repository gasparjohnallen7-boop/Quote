# QuoteFlow

Mobile-first SaaS starter for service-business quoting.

## Run locally
1. Install Node.js 20+.
2. `npm install`
3. Copy `.env.example` to `.env.local`.
4. Add Supabase credentials.
5. `npm run dev`

## Deploy
Push this repository to GitHub, import it into Vercel, add the environment variables, and deploy.

## Database
Create a Supabase project, open SQL Editor, and run `supabase/schema.sql`.

## Production checklist
- Add Supabase Auth UI and protected routes.
- Replace dashboard demo state with Supabase queries.
- Add server-side quote/customer APIs.
- Add PDF generation.
- Add Stripe Checkout and webhook.
- Add secure file storage for job photos.
- Add rate limiting, logging, backups, privacy policy and terms.
