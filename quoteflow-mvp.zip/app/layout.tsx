import "./globals.css";
export const metadata={title:"QuoteFlow",description:"Simple quoting and invoicing for service businesses"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}