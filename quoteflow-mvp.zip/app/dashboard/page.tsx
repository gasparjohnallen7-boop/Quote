 "use client";
import {useState} from "react";
type Quote={id:number,customer:string,job:string,total:number,status:string};
export default function Dashboard(){
 const [quotes,setQuotes]=useState<Quote[]>([
  {id:1,customer:"Maria Santos",job:"Brake service",total:8500,status:"Pending"},
  {id:2,customer:"Juan Cruz",job:"Oil change",total:3200,status:"Accepted"}
 ]);
 const [customer,setCustomer]=useState(""); const [job,setJob]=useState(""); const [total,setTotal]=useState("");
 function addQuote(e:React.FormEvent){e.preventDefault();if(!customer||!job||!total)return;
  setQuotes(q=>[{id:Date.now(),customer,job,total:Number(total),status:"Pending"},...q]);setCustomer("");setJob("");setTotal("");
 }
 const revenue=quotes.filter(q=>q.status==="Accepted").reduce((a,q)=>a+q.total,0);
 return <main style={{maxWidth:1100,margin:"0 auto",padding:20}}>
  <header style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:25}}><div><b style={{fontSize:25}}>QuoteFlow</b><div style={{color:"#71717a"}}>Business dashboard</div></div><button className="btn btn-secondary">Account</button></header>
  <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))",gap:15,marginBottom:20}}>
   {[["Quotes",quotes.length],["Accepted",quotes.filter(q=>q.status==="Accepted").length],["Revenue","₱"+revenue.toLocaleString()]].map(([a,b])=><div className="card" key={String(a)}><div style={{color:"#71717a"}}>{a}</div><strong style={{fontSize:28}}>{b}</strong></div>)}
  </div>
  <div style={{display:"grid",gridTemplateColumns:"minmax(280px,360px) 1fr",gap:20}}>
   <form className="card" onSubmit={addQuote}><h2>New quote</h2>
    <input placeholder="Customer name" value={customer} onChange={e=>setCustomer(e.target.value)} style={field}/>
    <input placeholder="Job description" value={job} onChange={e=>setJob(e.target.value)} style={field}/>
    <input placeholder="Total price" type="number" value={total} onChange={e=>setTotal(e.target.value)} style={field}/>
    <button className="btn btn-primary" style={{width:"100%"}}>Create quote</button>
   </form>
   <section className="card"><h2>Recent quotes</h2>
    {quotes.map(q=><div key={q.id} style={{display:"flex",justifyContent:"space-between",gap:10,padding:"15px 0",borderBottom:"1px solid #eee"}}>
      <div><b>{q.customer}</b><div style={{color:"#71717a"}}>{q.job}</div></div><div style={{textAlign:"right"}}><b>₱{q.total.toLocaleString()}</b><div style={{color:q.status==="Accepted"?"#15803d":"#a16207"}}>{q.status}</div></div>
    </div>)}
   </section>
  </div>
 </main>
}
const field={display:"block",width:"100%",padding:12,border:"1px solid #d4d4d8",borderRadius:10,margin:"10px 0 14px"};