import Link from "next/link";
export default function Home(){
 return <main>
  <nav style={{display:"flex",justifyContent:"space-between",padding:"20px max(20px,5vw)",background:"white",borderBottom:"1px solid #eee"}}>
   <b style={{fontSize:22}}>QuoteFlow</b><Link className="btn btn-primary" href="/dashboard">Open Demo</Link>
  </nav>
  <section style={{maxWidth:1000,margin:"0 auto",padding:"80px 20px",textAlign:"center"}}>
   <p style={{fontWeight:700}}>QUOTING MADE SIMPLE</p>
   <h1 style={{fontSize:"clamp(42px,8vw,78px)",lineHeight:1,margin:"20px 0"}}>Create quotes. Win jobs. Get paid.</h1>
   <p style={{fontSize:20,color:"#52525b",maxWidth:650,margin:"20px auto 30px"}}>A simple quoting and invoicing workspace for auto shops, contractors, cleaners, electricians and other service businesses.</p>
   <Link className="btn btn-primary" href="/dashboard">Try the dashboard →</Link>
  </section>
  <section style={{maxWidth:1000,margin:"0 auto",padding:"20px",display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:16}}>
   {["Customers","Quotes","Invoices","Revenue"].map(x=><div className="card" key={x}><h3>{x}</h3><p style={{color:"#71717a"}}>Organize your {x.toLowerCase()} in one place.</p></div>)}
  </section>
 </main>
}